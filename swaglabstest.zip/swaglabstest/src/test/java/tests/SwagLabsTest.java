package tests;

import org.testng.annotations.*;

import environmentsetup.baseclass;
import webpages.CartPage;
import webpages.HomePage;
import webpages.LoginPage;
import webpages.Logout;
import webpages.ProductPage;
import webpages.ProductPageTwo;
import webpages.RemoveItem;

public class SwagLabsTest extends baseclass {
	private LoginPage loginPage;
	private HomePage homePage;
	private ProductPage productPage;
	private ProductPageTwo productPage1;
	private RemoveItem removeone;
	private CartPage cartPage;
	private Logout logoutButton;

	@BeforeMethod
	public void setUpTest() {
		setup();
		loginPage = new LoginPage(getDriver());
		homePage = new HomePage(getDriver());
		productPage = new ProductPage(getDriver());
		productPage1 = new ProductPageTwo(getDriver());
		removeone = new RemoveItem(getDriver());
		cartPage = new CartPage(getDriver());
		logoutButton = new Logout(getDriver());
	}

	@Test
	public void testPurchaseProduct() throws InterruptedException {
		// Step 1: Login
		loginPage.enterUsername("standard_user");
		loginPage.enterPassword("secret_sauce");
		loginPage.clickLoginButton();
		Thread.sleep(7000);
		// Step 2: Navigate to Product
		homePage.clickOnProduct();
		Thread.sleep(7000);
		// Step 3: Add Product to Cart
		productPage.clickAddToCart();
		Thread.sleep(7000);

		// Step 4: Go to Cart
		productPage.navigateToCart();
		Thread.sleep(7000);

		productPage1.clickcontinueshopping();
		Thread.sleep(7000);

		productPage1.addtwoproduct();
		Thread.sleep(7000);

		removeone.RemoveItemone();
		Thread.sleep(7000);

		// Step 5: Checkout
		cartPage.clickCheckout();
		Thread.sleep(7000);

		logoutButton.logout();
		Thread.sleep(7000);
		System.out.println("Logout successful.");
	}


	

	/*public void tearDownTest() {
		tearDown();
		
		if (driver != null) {
			driver.close(); // Quit the WebDriver instance
			System.out.println("Driver quit successfully.");
		}
	}
}*/
	@AfterMethod
      public void  driverclose() {
		if (driver != null)
		driver.close();
		System.out.println("Driver quit successfully.");
	}
}





