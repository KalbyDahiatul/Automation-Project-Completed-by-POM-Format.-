package webpages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class Logout {
    private WebDriver driver;

    // Locators
    private By menuButton = By.id("react-burger-menu-btn");
    private By logoutButton = By.id("logout_sidebar_link");

    // Constructor
    public Logout(WebDriver driver) {
        this.driver = driver;
    }

    // Method to perform logout
    public void logout() throws InterruptedException {
        driver.findElement(menuButton).click(); // Click the menu button
        Thread.sleep(3000);
        driver.findElement(logoutButton).click(); // Click the logout button
        Thread.sleep(3000);
        System.out.println("Logout successful");
    }
}
