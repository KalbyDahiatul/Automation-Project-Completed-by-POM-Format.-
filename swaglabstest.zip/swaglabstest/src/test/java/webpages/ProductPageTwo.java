package webpages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class ProductPageTwo {
	private WebDriver driver;
	// Locators
	private By productLink1 = By.xpath("(//div[@class='pricebar']//button)[1]");
	private By productLink2 = By.xpath("(//div[@class='pricebar']//button)[2]");
	private By continueshopping = By.id("continue-shopping");
	private By cartButton1 = By.xpath("//div[@id='shopping_cart_container']//a[1]");

	// Constructor
	public ProductPageTwo(WebDriver driver) {
		this.driver = driver;
	}

	// Actions
	public void clickcontinueshopping() {
		driver.findElement(continueshopping).click();
	}

	public void addtwoproduct() {

		WebElement sortdropdown = driver.findElement(By.xpath("//span[@class='select_container']//select[1]"));
		Select select = new Select(sortdropdown);
		select.selectByVisibleText("Price (low to high)");
		System.out.println("low to high");
		driver.findElement(productLink1).click();
		driver.findElement(productLink2).click();
		driver.findElement(cartButton1).click();
		System.out.println("Two Product Purchase completed");
	}
}