package webpages;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
public class RemoveItem {
	
	private WebDriver driver;
	// Locators
	private By removeone = By.xpath("(//div[@class='item_pricebar']//button)[2]");
	
	// Constructor
	public RemoveItem(WebDriver driver) {
		this.driver = driver;
	}
	
	
	// Actions
	public void RemoveItemone() {
		System.out.println("before remove");
		driver.findElement(removeone).click();
		System.out.println("after remove");
		
		
	}
}
